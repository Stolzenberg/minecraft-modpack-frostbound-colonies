#!/usr/bin/env bash
# Frostbound Colonies 1.0.0 - Server-Installation (benötigt Java 21, curl)
set -euo pipefail
cd "$(dirname "$0")"
NEOFORGE=21.1.256
if [ ! -d libraries/net/neoforged/neoforge/$NEOFORGE ]; then
  curl -fL -o neoforge-installer.jar "https://maven.neoforged.net/releases/net/neoforged/neoforge/$NEOFORGE/neoforge-$NEOFORGE-installer.jar"
  java -jar neoforge-installer.jar --installServer .
  rm -f neoforge-installer.jar neoforge-installer.jar.log
fi
mkdir -p mods
while IFS=$'\t' read -r file url; do
  [ -z "$file" ] && continue
  [ -f "mods/$file" ] || { echo "Lade $file"; curl -fsL -o "mods/$file" "$url"; }
done < mods.txt
echo "Fertig. EULA in eula.txt akzeptieren, dann ./start.sh ausführen."
