# Frostbound Colonies 1.0.0 - Server-Installation fuer Windows (benoetigt Java 21)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$nf = "21.1.256"
if (-not (Test-Path "libraries/net/neoforged/neoforge/$nf")) {
  Invoke-WebRequest "https://maven.neoforged.net/releases/net/neoforged/neoforge/$nf/neoforge-$nf-installer.jar" -OutFile neoforge-installer.jar
  java -jar neoforge-installer.jar --installServer .
  Remove-Item neoforge-installer.jar*
}
New-Item -ItemType Directory -Force mods | Out-Null
Get-Content mods.txt | Where-Object { $_ } | ForEach-Object {
  $f, $u = $_ -split "`t"
  if (-not (Test-Path "mods/$f")) { Write-Host "Lade $f"; Invoke-WebRequest $u -OutFile "mods/$f" }
}
Write-Host "Fertig. EULA in eula.txt akzeptieren, dann start.bat ausfuehren."
