#!/usr/bin/env bash
cd "$(dirname "$0")"
exec java @user_jvm_args.txt @libraries/net/neoforged/neoforge/21.1.256/unix_args.txt nogui "$@"
