@echo off
java @user_jvm_args.txt @libraries/net/neoforged/neoforge/21.1.256/win_args.txt nogui %*
pause
